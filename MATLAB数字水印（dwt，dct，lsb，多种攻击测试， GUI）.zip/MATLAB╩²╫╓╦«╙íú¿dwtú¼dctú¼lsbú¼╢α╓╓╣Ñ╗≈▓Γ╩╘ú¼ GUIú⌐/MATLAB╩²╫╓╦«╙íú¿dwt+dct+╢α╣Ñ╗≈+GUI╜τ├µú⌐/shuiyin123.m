function varargout = shuiyin123(varargin)
% SHUIYIN123 MATLAB code for shuiyin123.fig
%      SHUIYIN123, by itself, creates a new SHUIYIN123 or raises the existing
%      singleton*.
%
%      H = SHUIYIN123 returns the handle to a new SHUIYIN123 or the handle to
%      the existing singleton*.
%
%      SHUIYIN123('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SHUIYIN123.M with the given input arguments.
%
%      SHUIYIN123('Property','Value',...) creates a new SHUIYIN123 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before shuiyin123_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to shuiyin123_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help shuiyin123

% Last Modified by GUIDE v2.5 12-May-2021 17:00:05

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @shuiyin123_OpeningFcn, ...
    'gui_OutputFcn',  @shuiyin123_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before shuiyin123 is made visible.
function shuiyin123_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to shuiyin123 (see VARARGIN)

% Choose default command line output for shuiyin123
handles.output = hObject;
set(gcf,'name','��ϵ΢�ţ�matlab1998   ');
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes shuiyin123 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = shuiyin123_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
[name,path]=uigetfile({'*.bmp';'gif'},'����ͼ��');

X=imread([path,name]);  %��ȡλ��
axes(handles.axes1);%axes��ʾ��ȡλ�ã�����ѡȡ��λ��Ϊaxes1��
imshow(X); %��ʾͼ��
save('X');  %�������
guidata(hObject,handles) %���½ṹ�壻


% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
[name,path]=uigetfile({'*.bmp';'gif'},'����ͼ��');

W=imread([path,name]);  %��ȡλ��
axes(handles.axes2);%axes��ʾ��ȡλ�ã�����ѡȡ��λ��Ϊaxes1��
W=rgb2gray(W)
W=imresize(W,[64 64])
imshow(W); %��ʾͼ��
save('W');  %�������
guidata(hObject,handles) %���½ṹ�壻

% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)

msgbox('������ϵ΢�ţ�matlab1998 ')

% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
axes(handles.axes5);
load('Z');
load key

Z=double(Z);
[XCsource,XSsource]=wavedec2(Z,3,'db1');
low=XCsource(1:4096);
lowarray=reshape(XCsource(1:4096),64,64);
std=result;

for i = 1:64
    ref1(i)=mean(lowarray(:,i));
    ref2(i)=mean(lowarray(i,:));
    for j=1:64
        pick(i,j,1)=xor(std(i,j,1),(lowarray(i,j)>ref1(i)));
        pick(i,j,2)=xor(std(i,j,2),(lowarray(i,j)>ref2(i)));
    end
    
end
for i=1:4096
    ref3tmp=[XCsource(16381+4*i:16384+4*i)];
    ref3(i)=mean(ref3tmp);
    ref4tmp=[XCsource(32765+4*i:32768+4*i)];
    ref4(i)=mean(ref3tmp);
    ref5tmp=[XCsource(49149+4*i:49152+4*i)];
    ref5(i)=mean(ref5tmp);
    ref6tmp=[XCsource(65521+16*i:65536+16*i)];
    ref6(i)=mean(ref6tmp);
    ref7tmp=[XCsource(131057+16*i:131072+16*i)];
    ref7(i)=mean(ref7tmp);
    ref8tmp=[XCsource(196593+16*i:196608+16*i)];
    ref8(i)=mean(ref8tmp);
end

alaph3=double(mean(low)/mean(ref3));
alaph4=double(mean(low)/mean(ref4));
alaph5=double(mean(low)/mean(ref5));
alaph6=double(mean(low)/mean(ref6));
alaph7=double(mean(low)/mean(ref7));
alaph8=double(mean(low)/mean(ref8));

reref3=reshape(ref3,64,64);
reref4=reshape(ref4,64,64);
reref5=reshape(ref5,64,64);
reref6=reshape(ref6,64,64);
reref7=reshape(ref7,64,64);
reref8=reshape(ref8,64,64);

for i =1:64
    for j=1:64
        pick(i,j,3)=xor(std(i,j,3),(lowarray(i,j)>(alaph3*reref3(i,j))));
        pick(i,j,4)=xor(std(i,j,4),(lowarray(i,j)>(alaph4*reref4(i,j))));
        pick(i,j,5)=xor(std(i,j,5),(lowarray(i,j)>(alaph5*reref5(i,j))));
        pick(i,j,6)=xor(std(i,j,6),(lowarray(i,j)>(alaph6*reref6(i,j))));
        pick(i,j,7)=xor(std(i,j,7),(lowarray(i,j)>(alaph7*reref7(i,j))));
        pick(i,j,8)=xor(std(i,j,8),(lowarray(i,j)>(alaph8*reref8(i,j))));
    end
end

for i=1:64
    for j=1:64
        od=double(reshape(pick(i,j,:),1,8));
        dec(i,j)=bin2dec(char(od+48));
    end
end



imshow(dec,[]);
save dec


load('W');
origImg=W;
distImg=dec;

%load('distImg');
%If the input image is rgb, convert it to gray image
noOfDim = ndims(origImg);
if(noOfDim == 3)
    origImg = rgb2gray(origImg);
end

noOfDim = ndims(distImg);
if(noOfDim == 3)
    distImg = rgb2gray(distImg);
end

%Size Validation
origSiz = size(origImg);
distSiz = size(distImg);
sizErr = isequal(origSiz, distSiz);
if(sizErr == 0)
    disp('Error: Original Image & Distorted Image should be of same dimensions');
    return;
end

%Mean Square Error

MSE = MeanSquareError(origImg, distImg);
%disp('Mean Square Error = ');
%disp(MSE);
%Peak Signal to Noise Ratio
PSNR = PeakSignaltoNoiseRatio(origImg, distImg);
set(handles.text5,'string',PSNR);







% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
axes(handles.axes3);
load('X');
X=double(X);
[XCsource,XSsource]=wavedec2(X,3,'db1');
load('W');
W=double(W); %'double'�������Ԫ�ر��˫����Ԫ��
lowarray=reshape(XCsource(1:4096),64,64); %convert matrix XCsource(1:4096) to a 64*64 matrix
low=XCsource(1:4096);

for i = 1:64
    ref1(i)=mean(lowarray(:,i)); %�Ծ���ÿ�����ֵ
    ref2(i)=mean(lowarray(i,:)); %�Ծ���ÿ�����ֵ
    for j=1:64
        w(i,j,:)=int8(dec2bin(W(i,j),8))-48; %dec2bin������W��ÿ��Ԫ��ת���ɶ�����ֵ��ÿ�������Ƴ���Ϊ8
        result(i,j,1)=xor(w(i,j,1),(lowarray(i,j)>ref1(i)));
        result(i,j,2)=xor(w(i,j,2),(lowarray(i,j)>ref2(i)));
    end
    
end
for i=1:4096
    ref3tmp=[XCsource(16381+4*i:16384+4*i)];%128*128=16384
    ref3(i)=mean(ref3tmp);
    ref4tmp=[XCsource(32765+4*i:32768+4*i)];%128*256=32768
    ref4(i)=mean(ref3tmp);
    ref5tmp=[XCsource(49149+4*i:49152+4*i)];%(128+64)*256=49152  or (128+256)*128=49152
    ref5(i)=mean(ref5tmp);
    ref6tmp=[XCsource(65521+16*i:65536+16*i)];%256*256=65536 or 128*512=65536
    ref6(i)=mean(ref6tmp);
    ref7tmp=[XCsource(131057+16*i:131072+16*i)];%256*512=131072
    ref7(i)=mean(ref7tmp);
    ref8tmp=[XCsource(196593+16*i:196608+16*i)];%(128+256)*512=196608
    ref8(i)=mean(ref8tmp);
end

alaph3=double(mean(low)/mean(ref3));
alaph4=double(mean(low)/mean(ref4));
alaph5=double(mean(low)/mean(ref5));
alaph6=double(mean(low)/mean(ref6));
alaph7=double(mean(low)/mean(ref7));
alaph8=double(mean(low)/mean(ref8));

reref3=reshape(ref3,64,64);
reref4=reshape(ref4,64,64);
reref5=reshape(ref5,64,64);
reref6=reshape(ref6,64,64);
reref7=reshape(ref7,64,64);
reref8=reshape(ref8,64,64);

for i =1:64
    for j=1:64
        result(i,j,3)=xor(w(i,j,3),(lowarray(i,j)>(alaph3*reref3(i,j))));
        result(i,j,4)=xor(w(i,j,4),(lowarray(i,j)>(alaph4*reref4(i,j))));
        result(i,j,5)=xor(w(i,j,5),(lowarray(i,j)>(alaph5*reref5(i,j))));
        result(i,j,6)=xor(w(i,j,6),(lowarray(i,j)>(alaph6*reref6(i,j))));
        result(i,j,7)=xor(w(i,j,7),(lowarray(i,j)>(alaph7*reref7(i,j))));
        result(i,j,8)=xor(w(i,j,8),(lowarray(i,j)>(alaph8*reref8(i,j))));
    end
end
save('key','result');

Y=waverec2(XCsource,XSsource,'db1');
Y=uint8(Y);

%imwrite(Y,'fuyonghua.bmp','bmp');

W=uint8(W);%��ʽת��




imshow(Y,[]);
save('Y');


% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
run mainfig
% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in radiobutton1.
function radiobutton1_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton1


% --- Executes on button press in radiobutton2.
function radiobutton2_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton2


% --- Executes on button press in radiobutton3.
function radiobutton3_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton3


% --- Executes on button press in radiobutton4.
function radiobutton4_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton4



function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double


% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit5_Callback(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit5 as text
%        str2double(get(hObject,'String')) returns contents of edit5 as a double


% --- Executes during object creation, after setting all properties.
function edit5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit6_Callback(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit6 as text
%        str2double(get(hObject,'String')) returns contents of edit6 as a double


% --- Executes during object creation, after setting all properties.
function edit6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit7_Callback(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit7 as text
%        str2double(get(hObject,'String')) returns contents of edit7 as a double


% --- Executes during object creation, after setting all properties.
function edit7_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit8_Callback(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit8 as text
%        str2double(get(hObject,'String')) returns contents of edit8 as a double


% --- Executes during object creation, after setting all properties.
function edit8_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton7.
function pushbutton7_Callback(hObject, eventdata, handles)
load Y
img=Y
imwrite(img,'����Ƕ��ˮӡ��ͼ.jpg')
msgbox('����ɹ����뵽�ļ��в鿴Ƕ��ˮӡ��ͼ��')
% hObject    handle to pushbutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton8.
function pushbutton8_Callback(hObject, eventdata, handles)
load dec
img=dec
imwrite(img,'������ȡˮӡ��ͼ.jpg')
msgbox('����ɹ����뵽�ļ��в鿴��ȡˮӡ��ͼ��')

% hObject    handle to pushbutton8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
