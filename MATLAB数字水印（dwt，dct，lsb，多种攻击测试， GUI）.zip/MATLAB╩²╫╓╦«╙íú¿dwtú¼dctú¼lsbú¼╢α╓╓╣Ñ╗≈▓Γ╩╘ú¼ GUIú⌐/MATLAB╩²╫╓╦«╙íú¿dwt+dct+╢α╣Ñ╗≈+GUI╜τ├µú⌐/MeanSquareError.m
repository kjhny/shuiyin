%Program for Mean Square Error Calculation

%Author : Athi Narayanan S
%Student, M.E, Embedded Systems,
%K.S.R College of Engineering
%Erode, Tamil Nadu, India.
%http://www.ksrce.ac.in/

function MSE = MeanSquareError(origImg, distImg)

origImg = double(origImg);
distImg = double(distImg);

[M N] = size(origImg);
error = origImg - distImg;
MSE = sum(sum(error .* error)) / (M * N);